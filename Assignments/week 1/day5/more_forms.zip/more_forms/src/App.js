import logo from './logo.svg';
import './App.css';
import UserForm from './components/FormValidation';

function App() {
  return (
    <div className="App">
      <UserForm/>
    </div>
  );
}

export default App;

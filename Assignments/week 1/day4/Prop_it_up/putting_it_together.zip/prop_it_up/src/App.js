import React from 'react'
import './App.css';
import NewComponent from './components/NewComponent'

function App() {
  return (
    <div className="App">
      <NewComponent firstName={"John"} lastName={"Smith"} age={45} hairColor={"Blonde"}/>
      <NewComponent firstName={"Millard"} lastName={"Fillmore"} age={50} hairColor={"Grey"}/>
      <NewComponent firstName={"Jane"} lastName={"Fonda"} age={65} hairColor={"Dirty Blonde"}/>
      <NewComponent firstName={"Maria"} lastName={"Dear"} age={35} hairColor={"Brown"}/>
    </div>
  );
}

export default App;
